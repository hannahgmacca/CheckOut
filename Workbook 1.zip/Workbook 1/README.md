# Workbook T1A1
#### Hannah McDonald


## Q1: Key Events in the Development of the Internet

### World Wide Web

*1989:* Tim Berners-lee saw the difficulty in tracking projects and computer systems of CERN\'92s thousands of researchers globally. All information was stored locally on a computer and on different programs. 

He invented a information management system which used hypertext to link documents on different computers. He refined this proposal and by 1990 had launched and coined it the *World Wide Web* (WWW).

The invention of the WWW allowed researchers from around the world to share research documents and thus, began the globalisation of the internet.

[(source)](https://www.webfx.com/blog/web-design/the-history-of-the-internet-in-a-nutshell/)


### The Domain Name System

*1984:* The domain name system was created alongside the Domain Name Servers.

This allowed addresses on the internet to be human friendly as the IP addresses were hard to remember. The domain name system converted IP addresses to domain names ( e.g. Google.com) by connecting to a websites domain name server. This meant users on the internet didn't need to remember 192.353.1.242 as an internet address and could associate internet resources through an alphabetical name.

This improved the usability and accessibly of the internet for users world wide.

[(source)](https://www.webfx.com/blog/web-design/the-history-of-the-internet-in-a-nutshell/)


### The Mosaic Web Browser

*1993:* Mosaic – first graphical web browser for the general public
The first graphical web browser that had a clean and ‘easily understood’ user interface.

There were other browsers but this one was more sophisticated and used HTML to display documents. The Mosaic browser was instrumental in commercializing and popularizing the web as it was the first browswer to integrate both text and media. [(source)](https://en.wikipedia.org/wiki/Mosaic_(web_browser)#:~:text=NCSA%20Mosaic%20was%20one%20of,News%20Transfer%20Protocol%2C%20and%20Gopher.)

The ability to access the WWW through an intuitive interface is what pushed many people to start using the web, and pushed more companies to start looking at what the internet could be capable of. 

[(source)](https://history-computer.com/mosaic-browser-history-of-the-ncsa-mosaic-internet-web-browser/)


### Hotmail

*1996:* First web-based service (Hotmail) goes live.
Hotmail launched their email service. This would allow users to communicate for free over email. Before the launch of HoTMail (a tribute to HTML), webmail was heavily commercialized and expensive for the everyday user to access. 

Access to Hotmail meant many people would gain interest in the internet and would begin the path of private, free virtual communication. 

[(source)](https://arstechnica.com/information-technology/2017/12/how-hotmail-changed-microsoft-and-email-forever/)


### Google is born

*1998:* Larry Page and Sergey Brin launch Google Search, the now most popular web-based search engine. Beginning as a search algorithm and seeing rapid growth, then in 2004 became public. 

This was notably followed by launch of google news (2002), Gmail (2004), google maps (2005) and then google chrome in 2008. It was this search engine that allowed users to find information on the web quickly, in conjunction with other launched online software products that improved the function and usability of the internet globally.

[(source)](https://en.wikipedia.org/wiki/History_of_Google)


## Q2: Key Technologies in the Development of the Internet

### Packets

A packet is a small segment of a larger message delivered over a network. It allows us to break up files and send data through cables and then be received an reassembled for users to see.

Without this technology, we would not be able to send data from one computer to another via a network. The internet is just one big network of computers and servers sending packets of data.

[(source)](https://www.cloudflare.com/learning/network-layer/what-is-a-packet/)


### IP Addresses

An IP address is a unique address that identifies a device on a local network or on the internet. 

[(source)](https://www.kaspersky.com/resource-center/definitions/what-is-an-ip-address)

They allow devices to identify where a packet is from and where it needs to get sent to. They contain location information vital for the internet to differentiate different computers, routers and websites.

The introduction of IoT devices has meant there are many more devices which use IP addresses. The traditional IPv4 addresses use 32-bit, so it accommodates for 4.23 billion devices, but the introduction of IPv6 addresses which are 128 bit accommodates 340,282,366,920,938,463,463,374,607,431,768,211,456 addresses.

IPv6 will be vital to accommodate for the increase in network devices as the internet and internet capable devices expand.

[(source)](https://www.thousandeyes.com/learning/techtorials/ipv4-vs-ipv6#:~:text=IPv4%20uses%20a%2032%2Dbit%20address%20for%20its%20Internet%20addresses.&text=IPv6%20utilizes%20128%2Dbit%20Internet,the%20number%20of%20IPv4%20addresses.)


### Routers and Routing

Routers are a type of network device that is responsible for routing the IP packets across different network links. They looks at the IP packet destination addresses and consult a routing table of known networks. They are vital to the development of the internat as they are what directs data to be sent over the internet and arrive at its intended location.

In order to reach distant networks, routers exchange information with neighbouring routers and building a their own routing table. This exchange of information which routers use is called a routing protocol.

[(source)](https://www.futurelearn.com/info/courses/introduction-to-networking/0/steps/53448#:~:text=Routers%20got%20their%20name%20because,routing%20table%20of%20known%20networks. )


### Domain Name System

Before the Domain Name System, resources online only belonged to an IP address which is not very human-friendly. In order for us to access information online we can now access them through alphabetic domain names.

The Domain Name System translates domain names to IP addresses so web browsers can load internet resources. This contributes to the development of the internet as it became easier to commercialize once humans could access websites through names, not IP address numbers.

[(source)](https://www.cloudflare.com/learning/dns/what-is-dns/)


## Q3: Client to Server Communications

### TCP

The Transmission Control Protocol  (TCP) is a communications standard designed so that packets are successfully delivered and guarantees the integrity of the data being communicated over a network.

TCP establishes a connection between source and its destination, and then breaks large amounts of data into smaller packets. It provides error connection and packet sequencing checks which makes it more reliable but also more network resource intense.

TCP primarily operates on the client/server structural model.  Rather than all devices and protocol software elements seen as peers they are seen as pairs, and this helps ensure the integrity of data sent between them.

[(source: TCP)](https://www.fortinet.com/resources/cyberglossary/tcp-ip)

[(source: Client-server)](http://www.tcpipguide.com/free/t_TCPIPServicesandClientServerOperation-2.htm)


### HTTP / HTTPS

HTTP stands for Hypertext Transfer Protocol. It sets the rules over which information is sent from a user’s web browswer to the website they are visiting. HTTP is the foundation of data communication for the world wide web, as it is the protocol for how hypertext and other content (images, video and audio) files from web browser to servers and back to web browser.

HTTPS is a more secure version of HTTP, is opens an encrypted connection between the web browser (client) and server so that data is enconed in a way that can’t be interfered or accessed by a third party. HTTP messages and data are sent as plain text, so anyone who is able to see your connection (via WIFI or via a computer between your computer and the web server) can read your messages.

HTTPS is important for the development of the internet as it allows critical information such as credit card info and personal correspondence to remain secure between client and server.

[(source)](https://www.techwalla.com/articles/the-advantages-of-hypertext-transfer-protocol)


### Web Browsers

A web browser loads a web page through a browser (client) request and is met by a server sending the HTML/CSS/JS/Img files. The browser is responsponsible for rendering these files and compute a graphical and functional web user interface.

This allows users of the internet (clients) to access a wide range of internet resources that exists on the millions of web servers all over the world. We can load the processing task to either be on the client or on the server. For example, mobile web apps require most of the processing to be server-side, but a website with rich animation will do mostly client-side processing.

The interne is the most used example of the client-server model, most of us use it everyday when accessing web servers on our computers and phone.

Every browser offers a range of developer tools to do a range of things. These tools improve the efficiency of debugging by allowing the user to access and inspect the HTML (a resource residing on a web-server typically) as a client.

[(source: Web Browsers)](https://softwareengineering.stackexchange.com/questions/138561/pros-cons-between-emphasizing-client-side-or-server-side-processing)

[(source: Developer Tools)](https://www.elegantthemes.com/blog/resources/why-you-should-start-using-chrome-developer-tools-right-now)


## Q4: Data Structures

### Array

An array is a data structure which stores objects one after another without gaps between them. An array indexes these objects for us to access, modify or remove them. 

They are an efficient way to store objects and are commonly used as a base for more advanced data structures (e.g store a collection of hashes within an array), to gather results from a loop or to collect and index items of a similar type. 
 

[(source)](https://www.rubyguides.com/2019/04/ruby-data-structures/)


### Hash

Hash is a data structure which allows us to map an object to a key. It allows us to link a value of data with a corresponding unique key.

It could best used for counting characters in a string, mapping words to definitions, names to phone numbers or to find duplicates inside an array.

They have better performance compared to array as they can link multiple values to the same key object.

[(source)](https://code-maven.com/basic-data-structures-in-ruby)


### Stack

A stack is like a sandwich where everything is on top of each other and you can only remove the topmost item. 


It’s very similar to an array but better used to organise data from first to last, for example keeping track of pages visited by a user so when they press the back button they access the last page visited.

[(source)](https://medium.com/@mshapir95/data-structures-in-ruby-a2b709d565be)


## Q5: Interpreters & Compilers

Source code is a high level language that can be understood by humans (containing words and phrases). Compilers and interpreters are programs both used to convert source code into machine code in order to be understood by computers.

An interpreter:
* Translates just one statement at a time
* Takes less time to analyze code but longer to execute
* Doesn’t generate an intermediary code so is highly efficient of memory
* Continues translating until first error is confronted (easier debugging)
* Is used by languages such as ruby and python

The key feature of an interpreter is that it parses the high-level source code and performs that commands directly [(source)](https://www.techopedia.com/definition/7793/interpreter). It takes longer overall but is helpful when debugging as it immediately recognizes an error.

A compiler:
* Scans entire program and translate whole of it into machine code
* Takes more time to analyse but a lot less time to execute the code (faster in general)* Always generates an intermediary objects (more memory is needed)
* Only spits error message after it scans the entire program
* Is used by languages such as C and C++

A compiler must scan the entire program and transform into machine code before the program runs, meaning it can only display all errors after compilation. This means it runs faster but is often not as troubleshoot friendly. 

[(source)](https://www.businessinsider.in/difference-between-compiler-and-interpreter/articleshow/69523408.cms#:~:text=Interpreter%20translates%20just%20one%20statement,to%20analyze%20the%20source%20code.)


## Q6 Programming Languages

### Ruby

Ruby is a high-level language that supports multiple programming paradigms.
These paradigms include procedural, object-orientated and functional programming.

Ruby was developed my Yukihiro Matsuoto with the philosophy for programmer productivity and fun. Its flexible design is purposeful as Matsumoto stressed that ‘design needs to emphasise human needs, rather than computer needs’.

Like many languages Ruby is object-orientated, meaning every value is a reference to an object. Notable benefits / features of Ruby are:

* It is open source and freely available on the web
* Dynamic typing: Data types do not need to be explicitly stated and any variable can hold any type of object
* Inheritance: Single inheritance only but provides support for modules and mixins for improved code reusibility
* Garbage collection: Ruby relieves the programmer from perofrming manual memory management
Literal notation for arrays, hashes & symbols
* Interactive Ruby Shell (IRB, an interactive command-line interpreter used to test code quickly)
* Uses interpretation instead of compiling when transforming to machine code which is better for debugging

Although Ruby is seen as a functional and convenient language, it is now considered a maturing language. 

Many developers consider it a ‘dying language’ [(Source)]( https://dev.to/remy29/on-death-and-dying-ruby-on-rails-5d7f).

Major drawbacks of Ruby are:
* Slow runtime speed
* Slow bootspeed
* Seen as a ‘niche’ language so harder to find specialists and resources
* Only best in web-based applications

[(source)]( https://thecodest.co/blog/pros-and-cons-of-ruby-software-development/)


### Java

Java is a general-purpose object-orientated programming language. It is very popular as it supports development for many platforms and browsers. Java is not only a language, but an ecosystem of tools used for development.

Tools include:
* Java Development Kit
* Java Runtime Envrionment
* Integrated Development Environment

Java also uses object-orientated programming to define its data, structure and functions. This allows programs to be organized into reusable objects and simplifies maintenance as a program matures.

Because of Java’s wide use and popularity, it is very successful in building enterprise applications. It supports a plethora of libraries and tools to help developer create any function or use-case a company may need.

Once Java is written and compiled to bytecode, you can run that application on any platform that supports Java virtual machine (most major operating systems), meaning program distribution is seamless.

Other notable features of Java include:
* Multithreading (multiple processing units to make better use of CPU, great in gaming and animation heavy programs)
* Large and stable ecosystem of well-tested libraries
* Huge Java community
* Constantly updated by Oracle with fresh and new features.

Some major drawbacks of programming in Java:
* Not open source as it is owned by Oracle, meaning any commercial development requires a licence.
* Poor performance due to compilation
* Available graphical user interface builders such as Swing, JavaFx etc are not as modern in terms of desktop web development
* Code is more complex and requires a lot more words to describe simple functions compared to languages like Python and Ruby

[(source)]( https://www.altexsoft.com/blog/engineering/pros-and-cons-of-java-programming/)


## Q7: Ethical Issues

### Freedom of Thought, Speech & Media

Software applications and the internet are the most common transfer of information in today’s society. A lot of this information can contain opinion, thought and personal speech. Because of this, developers play a large role in the facilitation of free speech around the world.

[Human Rights](https://humanrights.gov.au/our-work/3-freedom-expression-and-internet) helps defines the right to freedom of speech and the internet:

“By vastly expanding the capacity of individuals to enjoy their right to freedom of opinion and expression, which is an ‘enabler’ of other human rights, the Internet boosts economic, social and political development, and contributes to the progress of humankind as a whole.”

This statement reflects that the highest ethical responsibility of a developer is to ensure their software product allows users to enjoy their right to freedom of expression. Enabling their users to boost economic, social and political development through discussion through an internet platform is the greatest contribution to society a developer can bring. Thus, if a developer were to attempt to censor an opinion, discussion or thought then they would possibly be acting unethically. 

But what if a platform is being used to spread information or content that is harmful to the general public? 

For developers in Australia, the best source of information and case examples belongs on the Australian Parliament House website. Here you can read about the Broadcasting Services Act 1992, this act defines censorship guidelines and attempts to define how the internet should be regulated, even on an international level. 

The Broadcasting Services Act 1992 works to classify what is considered ‘harmful’ on the internet (and should be prohibited) and what is considered individuals enjoying their freedom of speech. Thus this law influences developers to produce products that can maintain balance between the two conflicting ethical issues.

[Australian Parliament House](https://www.aph.gov.au/About_Parliament/Parliamentary_Departments/Parliamentary_Library/pubs/rp/rp1415/InternetFiltering#_Toc395250006) discusses case studies, government policies, UN guidelines and even public criticism from Australia’s past and present. It would work as a great tool for a developer to better understand how to ethically create software that fits the changing needs of the global society.

[source: Freedom of Speech]https://www.aph.gov.au/About_Parliament/Parliamentary_Departments/Parliamentary_Library/pubs/rp/rp1415/InternetFiltering#_Toc395250006

### Case Study: Facebook News Ban

*“The Internet is a revolutionary source of information and its dissemination; and a medium for collaboration and interaction between individuals without regard for geographic location.”*
**APH.Gov.AU**

On the 17th February 2021, Facebook Announced it had blocked all news on its platform in Australia. This historic decision was met with waves of criticism from both the general public and Australian government. 

This decision arose after months of tension between Facebook and the Australian government, which had been pushing legislation that would force tech platforms to pay news publishers for their content [(source)](https://www.socialmediatoday.com/news/understanding-facebooks-news-ban-in-australia-and-what-it-means-for-the-p/595394/).

How did this decision impact the freedom of thought, speech and media in Australia?
Facebook has been a major source for Australians to read, share and discuss news since its launch in 2005. By removing Australia’s ability to publish and discuss anything considered news, Facebook is then putting an end to the communication of opinion and thought between many Australians.

It is not only access to information about political and social events that was effected in this decision, as news about Emergency services and critical information to the community would also be censored. 

But was this decision considered unethical?

Facebooks decision to remove news from its platform might have been a strike back at the Australian government, but it was an ethical decision made by them to ensure news conglomerates (such as the Rupert Murdock News Corp) would not be able to further control and capitalise on Australian media. A week after the ban was imposed, the Australian government backed away from the fight in order to bring news back on the platform [(source)](https://edition.cnn.com/2021/02/17/media/facebook-australia-news-ban/index.html).

Although much of our legislation works to assist developers to act in an ethical way, but this case is a great example of how developers and software companies may need to make independent decisions in order to avoid ethical breach.

There is a notable law lag when it comes to technological issues. IT professionals should not only understand their legal requirements but assess what is considered ethical to the general public at a given time. Ethics in IT advances just as much as the technology itself due to the changing nature of society. 

The best way to mitigate ethical breaches in the IT industry is to stay up to date with trending news, politics and community opinion. Social media platforms like Facebook, Twitter and media publications like Medium are great sources of conversation for developers to seek information on ethics. 

These conversations discuss the actions of organisation and the technology that is yet to come. Using government recommendations and legislations alone is not enough to be ethical as an IT professional as there is too much of a delay due to changing technology.
And as seen in the Facebook news ban earlier this year, the government may not be working in favour of the general public. 

[Source: Facebook history](https://www.facebook.com/australianhistory/)
[Source: News ban](https://www.theguardian.com/technology/2021/feb/27/facebook-australia-news-ban-us-legislation)



### Access to Personal Information

Software applications often require access to a user’s personal information in order to provide functionality. From name and address to financial information, our apps store and access data relating to us and use it to help us perform everyday tasks. Developers of these applications must take responsibility for ensuring they have users consent to access, store or modify this data. They also have the responsibility of ensuring that their systems are secure from 3rd party access, and if they don’t manage this then they must alert users of a data breach. 

This responsibility is not just from an ethical standpoint, as there are Australian and international regulations which govern the way companies can store, access and protect our data.

The [Library of Congress Law](https://www.loc.gov/law/help/online-privacy-law/2012/australia.php#:~:text=The%20federal%20Privacy%20Act%201988,the%20online%20context%20in%20Australia.&text=There%20is%20no%20established%20cause,%2C%20statutory%2C%20or%20common%20law.) government website is a reputable source for developers to better understand the Privacy Act 1998. This website defines the framework for online data protection and defines how organizations should act accordingly in relation to the Privacy Act 1998. Notable court decisions made under this act are highlighted on the website, so developers could use these precedents to better understand what is legal and what is ethical. 

From data breaches, notifications, data access & deletion to online behavioural advertising, there is a wealth of topics covered by the Privacy Act 1998 that influence Australian developers to only create applications that protect personal privacy.

The Privacy Act 1998 is primary legislation which controls the collection, use, storage and deletion of information. It protects users to ensure that data collection is purposeful, fair and that organisations take responsibility for what has been collected.
This helps influence developers to make ethical decisions, as the requirements defined in this act prevent misuse and exploitation of data without legal ramification.


## Q8: Control Structures

Control flow allows execute a certain statement under a specific condition. We call these control flows loops as they often allow us to loop blocks of code multiple times until we meet a desired condition or to search for a specific object of data within a data structure.

When the program is run, the statements are executed from the top of the source file to the bottom. In Ruby, this can be done using multiple statements such as:

* If statement
* Case statement
* While / until statements
* For statements
* Break / next statements

An example of an if statement in pseudocode:

**If** condition is true

	Execute this code

**Else if** other condition

	Execute this code

**Else** neither above conditions are met

	Execute this code

**End** control flow



An example of an if statement in ruby code:

**if** x == y

	puts x

**elsif** x > y

	puts y


**else** 

	puts "X is smaller than Y"

**end** 


[(source)](https://zetcode.com/lang/rubytutorial/flowcontrol/)


## Q9: Type Coercion

Data type coercion allows us to change an objects’ type into another type. This is often required in programming when handling user input or when passing data from one function to another.

This can be done explicitly with methods such as to_s, to_i, and to_a.
These transform one value to another by always returning the converted, even if it doesn’t convert well.
E.g 3.4.to_i returns 3

We can also use a more resilient coercion method when the type is unknown. 
For example the String(…) tries to call #to_stri and when that fails calls the #to_s method discussed above. The to_str method uses implicit type coercion and will only return a value if the type suits it. 

[(source)](https://blog.appsignal.com/2018/09/25/explicitly-casting-vs-implicitly-coercing-types-in-ruby.html#:~:text=Type%20coercion%20is%20the%20changing,into%20an%20Integer%20with%20%23to_i%20.&text=Let's%20first%20look%20at%20how,Ruby%20with%20explicit%20casting%20helpers.)


## Q10: Data Types

Data types is an attribute of data which tells the interpreter or compiler how the programmer plans to use the data [(source)](https://en.wikipedia.org/wiki/Data_type). 

This is because the way data is store, accessed and modified in a program is often dependent on its type.

**String**

A string is a sequence of characters, e.g “coding”.

It is declared between a set of double quotation marks.

**Integer**

This is a data type which store whole numbers. 

e.g 1, -30, 45 

**Boolean**

This stores 1 of 2 values. Usually denoted as true and false.

E.g is_a_match = true 

From these examples you can see that if data is a true or false (Boolean) it will be used to represent a condition or state, which couldn’t be used in an equation. 


## Q11: Restaurant case

The following class diagram displays the superclasses and subclasses used in an app replacing restuarant staff:

![Class Diagram](img/class_diagram.png)


**MenuItem**

*Super class of all food items in restaurant*

Holds name and price of food item.


**Food**

*Subclass of MenuItem*

Holds ingredients in food and whether or not food is vegetarian or gluten free.


**Meal**

*Subclass of Food*

Holds description of meal as this is listed next to all meal items in app.

Meal items are allowed extras to be added (cannot do this on sides). Some meals are not allowed to be ordered takeaway also.


**KidsMeal**

*Subclass of Meal*

Holds whether or not meal is for a boy or girl as kids meals are served with 'boy' or 'girl' packaging and toy.


**Side**

*Subclass of Food*

Holds size of side (usually small, medium or large) and all sides come with free sauce.


**Drink**

*Subclass of MenuItem*

Holds size of drink.

**HousemadeDrink**

*Subclass of Drink*

Has many attributes required for in-house made drinks. Such as ingredients and extras.

If drink is alcoholic then app must check age of user. 

If it is hot app will prioritise delivery to user.

This class overrides size attribute from Drink class to store small, medium or large.

**FridgeDrink**

*Subclass of Drink*

Stores supplier of drink and stock count of how many bottles left.

Also overrides size attribute from Drink class to store a value in millilitres.

**Order**

*Superclass of all order types*

Holds ordersID and customerID of customer that placed the order (customerID connected to a customer object that will have their details).

Generates a date stamp and stores in variable of date_placed when order is created.

**Delivery**

*Subclass of Order*

Stores address of delivery. Customers have option to set delivery for a later time so this is stored in delivery_time.

This class will calculate additional delivery costs based off address and store in a variable also.

**Pick-up**

*Subclass of Order*

Customers may specify a pick-up time for their order.

**Dine-In**

*Subclass of Order*

If reservation is made the DineIn class will store this in booking_time, otherwise the time they walk in and request a table will be entered.

Table number and if it is for a birthday is stored here also.

**Person**

*Superclass of all people in restaurant*

Used to store identification information about a person, such as name and address.

**Customer**

*Subclass of Person*

Stores loyalty points, order history and payment method.


## Q12: Code Snippet

The Celsius variable is storing a data type of string as gets will default input from user as a string even if it’s a number entered. 

When Fahrenheit is being calculates the Celsius variable in an equation using integer numbers, which would cause an error as a string cannot be used as input in a mathematical formula.


## Q13: Code Snippet 2

```ruby
arr = [5,22,29,39,19,51,78,96,84]

i = 0

while (i < arr.size - 1 and arr[i] < arr[i+1])

	i += 1 end 

arr[i + 1], arr[i] = arr[i], arr[i+1]

puts arr
```


## Q14: Prime Numbers

Set variable n to 100

x = n - 1


if (n / x is a whole number)

	n = n - 1

	if n == 1

		run the loop again

	else
		loop is complete

else if (n / x is not a whole number)

	if x == 1

		print "n is a prime number!"

		n = n - 1

		if n = 1

			loop is complete

		else

		  	x = n - 1 (reloop)

		end

	else
	
		x = x - 1 (reloop)

	end


![Prime Numbers Flowchart](img/flowchart.png)

## Q15: Pseudocode

```ruby
if raining && (temp < 15)
	puts "It's wet and cold"
elsif !(raining) && (temp < 15)
	puts "It's not raining but cold"
elsif !(raining) && (temp >= 15 )
	puts "It's warm but not raining"
else
	puts "It's warm and raining"
end
```

## Q16: ACME Corp

```ruby
run_loop = true

skills = { 
	"python" => 1, "ruby" => 2, "bash" => 4, "git" => 8, "html" => 16, "tdd" => 32, "css" => 64, "javascript" => 128 
	} 

while run_loop

carried_skills = []

coding_score = 0 

puts "WELCOME TO ACME CODING SKILLS CALCULATOR\n\n"
puts "What coding skills from the following do you carry?\n\n"

skills.each { |skill, score| puts "* #{skill}" }

puts "Type done when you have finished entering skills\n\n"

input = gets.strip

while !(input == "done") 

	if skills.include?(input) && !(carried_skills.include?(input))
		carried_skills << input
		coding_score += skills[input]
	elsif carried_skills.include?(input)
		puts "You have already entered this skill.\n\n"
	elsif input == "done"
		puts "\n\n"
		break
	else
		puts "This skill isn't a skill we are looking for."
		puts "Please enter a skill from the list.\n\n"
	end
	input = gets.strip.downcase
end

puts "You have a coding score of #{coding_score}!"
puts "Here are skills you haven't learn and the points they are worth:\n\n"

skills.each do |skill, score| 
	if !(carried_skills.include?(skill))
		puts "* #{skill}: #{score}"
	end
end

run_loop = false

end
```